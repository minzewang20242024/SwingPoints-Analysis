import os

from swing_point_detector import SwingPointDetector
from stock_analyzer import StockAnalyzer
from signal_evaluator import SignalEvaluator

def get_user_input() -> dict:
    """
    User Interactive Input: Obtain parameters such as stock ticker, dates and calculation methods.
    :return: User input configuration dictionary
    """
    print("=" * 60)
    print("        Large-Cap Tech Stock Trend Analysis Tool (Supports True/False Breakout/Breakdown Detection)")
    print("=" * 60)

    # Step 1: Obtain core parameters first
    ticker = input("Please enter stock ticker (e.g., AAPL, MSFT): ").strip() or "AAPL"
    start_date = input("Please enter analysis start date (format YYYY-MM-DD): ").strip() or "2024-01-01"
    end_date = input("Please enter analysis end date (format YYYY-MM-DD): ").strip() or "2024-12-31"
    data_source = input("Please select data source (only support 'yahoo', press Enter for default 'yahoo'): ").strip() or "yahoo"
    swing_method = input("Please select swing point detection method (fixed/adaptive, press Enter for default 'fixed'): ").strip() or "fixed"
    holding_period = int(input("Please enter signal verification holding period (default 10, press Enter for default 10): ").strip() or 10)
    min_threshold = float(input("Please enter minimum price change threshold (default 0.03, press Enter for default 0.03): ").strip() or 0.03)
    output_dir = "./output_data"
    filename_input = input('Please enter result file name (without .xlsx, press Enter for default current stock ticker): ').strip() or ticker
    output_filename = f"{filename_input}_analysis.xlsx"

    # Step 2: Assemble into config dictionary
    config = {
        "ticker": ticker,
        "start_date": start_date,
        "end_date": end_date,
        "data_source": data_source,
        "swing_method": swing_method,
        "holding_period": holding_period,
        "min_threshold": min_threshold,
        "output_dir": output_dir,
        "output_filename": output_filename
    }

    print("\n" + "=" * 60)
    print("                    User Configuration Parameters Confirmation")
    print("=" * 60)
    for key, value in config.items():
        print(f"{key}: {value}")
    print("=" * 60 + "\n")

    return config

def main():
    """
    Main Function: Run complete analysis pipeline with one click (user input → data download → swing point detection → trend fitting → signal verification → result export → plot generation).
    Adapts to the new project structure, all outputs are saved to output_data/ and reports/ folder.
    """
    # Step 1: Obtain user input configuration
    config = get_user_input()

    # Step 2: Create output directory (output_data/) and report directory (reports/) if it does not exist
    report_dir = "./reports"  # 新增：定义图表报告目录
    for dir_path in [config["output_dir"], report_dir]:
        if not os.path.exists(dir_path):
            os.makedirs(dir_path)
    output_path = os.path.join(config["output_dir"], config["output_filename"])

    # Step 3: Initialize analysis and evaluation classes (from src/ package)
    try:
        # Initialize stock analysis class
        analyzer = StockAnalyzer(
            ticker=config["ticker"],
            start_date=config["start_date"],
            end_date=config["end_date"]
        )

        # Initialize signal evaluation class
        evaluator = SignalEvaluator(
            holding_period=config["holding_period"],
            min_threshold=config["min_threshold"]
        )

        # Step 4: Execute complete analysis pipeline
        # 4.1 Download data
        analyzer.download_data(data_source=config["data_source"])

        # 4.2 Detect swing points
        analyzer.detect_swing_points(swing_method=config["swing_method"])

        # 4.3 Fit trend lines
        analyzer.fit_trend_lines()

        # 4.4 Detect candidate signals
        analyzer.detect_signals()

        # 4.5 Evaluate true/false signals
        analysis_result = analyzer.get_analysis_result()
        evaluation_result = evaluator.evaluate_signals(
            analyzer_result=analysis_result,
            false_negative_breakout=1,
            false_negative_breakdown=0
        )

        # 4.6 Export results to Excel (saved to output_data/ folder)
        evaluator.export_to_excel(output_path)

        # 4.7 Generate visualization plots (saved to reports/ folder, Task 2 core requirement)
        evaluator.generate_plots(report_dir=report_dir)

        # Step 5: Print core performance metrics
        print("\n" + "=" * 60)
        print("                    Core Performance Metrics Summary")
        print("=" * 60)
        print("=== Swing Point Metrics ===")  # 新增：摆动点指标汇总
        swing_accuracy = evaluation_result["swing_stats"]["overall_swing_accuracy"]
        print(f"Overall Swing Point Accuracy: {swing_accuracy:.2%}")
        print("\n=== Breakout Signal Metrics ===")
        for metric, value in evaluation_result["breakout_derived_metrics"].items():
            print(f"{metric}: {value:.2%}")
        print("\n=== Breakdown Signal Metrics ===")
        for metric, value in evaluation_result["breakdown_derived_metrics"].items():
            print(f"{metric}: {value:.2%}")
        print("=" * 60)
        print("\n All analysis pipelines have been executed successfully!")
        print(f" Results (Excel) are saved to: {output_path}")
        print(f" Visual plots are saved to: {report_dir}")  # 新增：图表路径提示

    except Exception as e:
        print(f"\n An error occurred during execution: {str(e)}")

if __name__ == "__main__":
    main()