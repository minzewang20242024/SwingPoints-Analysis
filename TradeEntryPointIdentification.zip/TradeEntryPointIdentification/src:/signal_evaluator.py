import pandas as pd
import numpy as np
from typing import Optional
import matplotlib.pyplot as plt
import os

class SignalEvaluator:
    """
    Signal Evaluation Class (Optimized for Large-Cap Tech Stocks)
    Functionality: Verify true/false breakout/breakdown signals, calculate performance metrics, 
                   evaluate swing points, export results to Excel, and generate visualization plots.
    Core data is initialized via __init__, and users can customize verification parameters.
    """

    def __init__(self, holding_period: int = 10, min_threshold: float = 0.03, vol_multiplier: float = 1.5):
        """
        Class Initialization: Initialize core verification parameters and result storage.
        :param holding_period: Signal verification holding period (default 10, optimized value for large-cap tech stocks after justification)
        :param min_threshold: Minimum price change threshold (default 0.03=3%, filter minor fluctuations)
        :param vol_multiplier: Volume synergy multiplier (default 1.5, verify capital consensus)
        """
        # Core parameter initialization (default values justified for large-cap tech stocks)
        self.holding_period = holding_period
        self.min_threshold = min_threshold
        self.vol_multiplier = vol_multiplier

        # Core data initialization (passed via subsequent methods for flexibility)
        self.prices = pd.Series()
        self.volume = pd.Series()
        self.uptrend_line = None
        self.downtrend_line = None
        self.swing_highs = []  # Swing high indices storage
        self.swing_lows = []   # Swing low indices storage

        # Evaluation result storage
        self.evaluation_result = {}
        self.breakout_verification = []
        self.breakdown_verification = []
        self.swing_evaluation = {}  # Swing point evaluation result storage

    def _verify_breakout_single(self, signal_idx: int) -> str:
        """
        Helper Method: Verify true/false of a single candidate breakout signal (holding period + price change threshold).
        :param signal_idx: Signal index
        :return: Verification result ("TPB" = True Positive Breakout, "FPB" = False Positive Breakout, "Unverifiable" = Cannot be verified)
        """
        # Boundary judgment: insufficient subsequent data to verify at the end of the signal series
        if signal_idx + self.holding_period >= len(self.prices):
            return "Unverifiable"

        # Extract core data
        signal_price = self.prices.iloc[signal_idx]
        trendline_price = self.downtrend_line[signal_idx]
        post_signal_prices = self.prices.iloc[signal_idx: signal_idx + self.holding_period + 1]

        # Calculate verification metrics
        post_high = post_signal_prices.max()
        post_low = post_signal_prices.min()
        max_gain = (post_high - signal_price) / signal_price  # Maximum gain (decimal form)
        is_support_valid = (post_low >= trendline_price)  # Whether resistance-to-support conversion is effective

        # True/false judgment (quantitative standards for large-cap tech stocks)
        if max_gain >= self.min_threshold and is_support_valid:
            return "TPB"
        elif max_gain < self.min_threshold and post_low < trendline_price:
            return "FPB"
        else:
            return "Unverifiable"

    def _verify_breakdown_single(self, signal_idx: int) -> str:
        """
        Helper Method: Verify true/false of a single candidate breakdown signal (holding period + price change threshold).
        :param signal_idx: Signal index
        :return: Verification result ("TPBd" = True Positive Breakdown, "FPBd" = False Positive Breakdown, "Unverifiable" = Cannot be verified)
        """
        # Boundary judgment: insufficient subsequent data to verify at the end of the signal series
        if signal_idx + self.holding_period >= len(self.prices):
            return "Unverifiable"

        # Extract core data
        signal_price = self.prices.iloc[signal_idx]
        trendline_price = self.uptrend_line[signal_idx]
        post_signal_prices = self.prices.iloc[signal_idx: signal_idx + self.holding_period + 1]

        # Calculate verification metrics
        post_low = post_signal_prices.min()
        post_high = post_signal_prices.max()
        max_loss = (signal_price - post_low) / signal_price  # Maximum loss (decimal form)
        is_resistance_valid = (post_high <= trendline_price)  # Whether support-to-resistance conversion is effective

        # True/false judgment (quantitative standards for large-cap tech stocks)
        if max_loss >= self.min_threshold and is_resistance_valid:
            return "TPBd"
        elif max_loss < self.min_threshold and post_high > trendline_price:
            return "FPBd"
        else:
            return "Unverifiable"

    def _calculate_performance_metrics(self, true_positive: int, false_positive: int, false_negative: int) -> dict:
        """
        Helper Method: Calculate classification performance metrics (Precision, Recall, F1-Score, False Signal Rate).
        :param true_positive: Number of true positives
        :param false_positive: Number of false positives
        :param false_negative: Number of false negatives
        :return: Dictionary of performance metrics
        """
        # Avoid division by zero (metrics are 0 when there are no signals)
        total_detected = true_positive + false_positive
        total_actual = true_positive + false_negative

        # Calculate core metrics
        precision = true_positive / total_detected if total_detected > 0 else 0.0
        recall = true_positive / total_actual if total_actual > 0 else 0.0
        f1_score = 2 * (precision * recall) / (precision + recall) if (precision + recall) > 0 else 0.0
        false_signal_rate = false_positive / total_detected if total_detected > 0 else 0.0

        # Format results (retain 4 decimal places for better readability)
        return {
            "precision": round(precision, 4),
            "recall": round(recall, 4),
            "f1_score": round(f1_score, 4),
            "false_signal_rate": round(false_signal_rate, 4)
        }

    def _evaluate_swing_points(self, swing_highs: list, swing_lows: list, window_size: int = 3) -> dict:
        """
        Helper Method: Evaluate swing highs/lows accuracy (verify if they are local extremums).
        :param swing_highs: List of swing high indices (from StockAnalyzer)
        :param swing_lows: List of swing low indices (from StockAnalyzer)
        :param window_size: Local window size to verify extremums (default 3, match SwingPointDetector)
        :return: Swing point evaluation result dictionary
        """
        if self.prices.empty:
            raise ValueError("Prices are empty. Cannot evaluate swing points.")
        
        swing_stats = {
            "true_swing_highs": 0,
            "false_swing_highs": 0,
            "true_swing_lows": 0,
            "false_swing_lows": 0,
            "swing_high_accuracy": 0.0,
            "swing_low_accuracy": 0.0,
            "overall_swing_accuracy": 0.0
        }
        
        for high_idx in swing_highs:
            start_idx = max(0, high_idx - window_size)
            end_idx = min(len(self.prices) - 1, high_idx + window_size)
            window_prices = self.prices.iloc[start_idx:end_idx+1]
            
            if self.prices.iloc[high_idx] == window_prices.max():
                swing_stats["true_swing_highs"] += 1
            else:
                swing_stats["false_swing_highs"] += 1
        
        for low_idx in swing_lows:
            start_idx = max(0, low_idx - window_size)
            end_idx = min(len(self.prices) - 1, low_idx + window_size)
            window_prices = self.prices.iloc[start_idx:end_idx+1]
            
            if self.prices.iloc[low_idx] == window_prices.min():
                swing_stats["true_swing_lows"] += 1
            else:
                swing_stats["false_swing_lows"] += 1
        
        total_highs = swing_stats["true_swing_highs"] + swing_stats["false_swing_highs"]
        total_lows = swing_stats["true_swing_lows"] + swing_stats["false_swing_lows"]
        
        swing_stats["swing_high_accuracy"] = swing_stats["true_swing_highs"] / total_highs if total_highs > 0 else 0.0
        swing_stats["swing_low_accuracy"] = swing_stats["true_swing_lows"] / total_lows if total_lows > 0 else 0.0
        swing_stats["overall_swing_accuracy"] = (swing_stats["true_swing_highs"] + swing_stats["true_swing_lows"]) / (total_highs + total_lows) if (total_highs + total_lows) > 0 else 0.0
        
        for key in ["swing_high_accuracy", "swing_low_accuracy", "overall_swing_accuracy"]:
            swing_stats[key] = round(swing_stats[key], 4)
        
        self.swing_evaluation = swing_stats
        return swing_stats

    def evaluate_signals(self, analyzer_result: dict, false_negative_breakout: int = 0, false_negative_breakdown: int = 0) -> dict:
        """
        Core Method: Batch verify all candidate signals and calculate performance metrics.
        :param analyzer_result: Analysis result dictionary from StockAnalyzer
        :param false_negative_breakout: Number of false negative breakouts (missed valid signals, manually labeled)
        :param false_negative_breakdown: Number of false negative breakdowns (missed valid signals, manually labeled)
        :return: Complete evaluation result dictionary
        """
        # Extract core data from analysis results (initialize class data)
        self.prices = analyzer_result["data"]["prices"]
        self.volume = analyzer_result["data"]["volume"]
        self.uptrend_line = analyzer_result["trendlines"]["uptrend_line"]
        self.downtrend_line = analyzer_result["trendlines"]["downtrend_line"]
        breakout_indices = analyzer_result["signals"]["breakout_indices"]
        breakdown_indices = analyzer_result["signals"]["breakdown_indices"]
        
        # Extract swing points data from analyzer result
        swing_highs = analyzer_result["swing_points"]["swing_highs_indices"] if "swing_highs_indices" in analyzer_result["swing_points"] else []
        swing_lows = analyzer_result["swing_points"]["swing_lows_indices"] if "swing_lows_indices" in analyzer_result["swing_points"] else []
        self.swing_highs = swing_highs
        self.swing_lows = swing_lows

        # Batch verify breakout signals
        self.breakout_verification = [self._verify_breakout_single(idx) for idx in breakout_indices]

        # Batch verify breakdown signals
        self.breakdown_verification = [self._verify_breakdown_single(idx) for idx in breakdown_indices]

        # Statistic basic metrics
        breakout_stats = {
            "TPB": self.breakout_verification.count("TPB"),
            "FPB": self.breakout_verification.count("FPB"),
            "FNB": false_negative_breakout,
            "TNB": len(self.prices) - len(breakout_indices) - false_negative_breakout - self.breakout_verification.count("Unverifiable"),
            "unverifiable": self.breakout_verification.count("Unverifiable")
        }

        breakdown_stats = {
            "TPBd": self.breakdown_verification.count("TPBd"),
            "FPBd": self.breakdown_verification.count("FPBd"),
            "FNBd": false_negative_breakdown,
            "TNBd": len(self.prices) - len(breakdown_indices) - false_negative_breakdown - self.breakdown_verification.count("Unverifiable"),
            "unverifiable": self.breakdown_verification.count("Unverifiable")
        }

        # Calculate performance metrics (Precision, Recall, F1-Score)
        breakout_derived = self._calculate_performance_metrics(
            breakout_stats["TPB"], breakout_stats["FPB"], breakout_stats["FNB"]
        )

        breakdown_derived = self._calculate_performance_metrics(
            breakdown_stats["TPBd"], breakdown_stats["FPBd"], breakdown_stats["FNBd"]
        )
        
        # Evaluate swing points and get results
        swing_stats = self._evaluate_swing_points(swing_highs, swing_lows)

        # Organize final results
        self.evaluation_result = {
            "swing_stats": swing_stats,
            "breakout_stats": breakout_stats,
            "breakdown_stats": breakdown_stats,
            "breakout_derived_metrics": breakout_derived,
            "breakdown_derived_metrics": breakdown_derived,
            "verification_details": {
                "holding_period": self.holding_period,
                "min_threshold": self.min_threshold,
                "breakout_verification": self.breakout_verification,
                "breakdown_verification": self.breakdown_verification,
                "swing_highs": swing_highs,
                "swing_lows": swing_lows
            }
        }

        print("Signal evaluation completed. All performance metrics have been calculated.")
        return self.evaluation_result

    def export_to_excel(self, excel_path: str) -> None:
        """
        Core Method: Export evaluation results to Excel file (facilitate subsequent analysis and report writing).
        :param excel_path: Excel file save path
        """
        if not self.evaluation_result:
            raise ValueError("Evaluation result is empty. Please call evaluate_signals() to complete signal evaluation first.")

        # Write to Excel file, store results in 4 worksheets
        try:
            with pd.ExcelWriter(excel_path, engine="openpyxl") as writer:
                # Worksheet 1: Swing point statistics
                swing_df = pd.DataFrame.from_dict(self.evaluation_result["swing_stats"], orient="index", columns=["Value"])
                swing_df.to_excel(writer, sheet_name="Swing_Stats")

                # Worksheet 2: Breakout signal statistics
                breakout_df = pd.DataFrame.from_dict(self.evaluation_result["breakout_stats"], orient="index", columns=["Value"])
                breakout_df.to_excel(writer, sheet_name="Breakout_Stats")

                # Worksheet 3: Breakdown signal statistics
                breakdown_df = pd.DataFrame.from_dict(self.evaluation_result["breakdown_stats"], orient="index", columns=["Value"])
                breakdown_df.to_excel(writer, sheet_name="Breakdown_Stats")

                # Worksheet 4: Derived performance metrics
                derived_df = pd.DataFrame({
                    "Breakout": self.evaluation_result["breakout_derived_metrics"].values(),
                    "Breakdown": self.evaluation_result["breakdown_derived_metrics"].values()
                }, index=self.evaluation_result["breakout_derived_metrics"].keys())
                derived_df.to_excel(writer, sheet_name="Derived_Metrics")

            print(f"Evaluation results have been successfully exported to Excel file: {excel_path}")
        except Exception as e:
            raise Exception(f"Failed to export Excel file: {str(e)}")
    
    def generate_plots(self, report_dir: str = "./reports/") -> None:
        """
        Core Method: Generate visualization plots for signal evaluation results (save to report directory).
        Plots include: 
        1. Breakout/Breakdown True/False Statistics Bar Chart
        2. Performance Metrics (Precision/Recall/F1) Comparison Chart
        3. Price Trend with Signal Verification Markers (if prices are available)
        :param report_dir: Directory to save plots (create if not exists)
        """
        # 校验：评估结果不能为空
        if not self.evaluation_result:
            raise ValueError("Evaluation result is empty. Please call evaluate_signals() first.")
        
        if not os.path.exists(report_dir):
            os.makedirs(report_dir)
            print(f"Created report directory: {report_dir}")
        
        plt.figure(figsize=(14, 6))
        
        breakout_stats = self.evaluation_result["breakout_stats"]
        breakdown_stats = self.evaluation_result["breakdown_stats"]
        x_labels = ["TPB/TPBd", "FPB/FPBd", "FNB/FNBd", "TNB/TNBd"]
        breakout_values = [breakout_stats["TPB"], breakout_stats["FPB"], breakout_stats["FNB"], breakout_stats["TNB"]]
        breakdown_values = [breakdown_stats["TPBd"], breakdown_stats["FPBd"], breakdown_stats["FNBd"], breakdown_stats["TNBd"]]
        
        x = np.arange(len(x_labels))
        width = 0.35
        
        plt.bar(x - width/2, breakout_values, width, label="Breakout", color="#2E8B57", alpha=0.8)
        plt.bar(x + width/2, breakdown_values, width, label="Breakdown", color="#DC143C", alpha=0.8)
        
        plt.title("Breakout & Breakdown True/False Signal Statistics", fontsize=12)
        plt.xlabel("Signal Type", fontsize=10)
        plt.ylabel("Count", fontsize=10)
        plt.xticks(x, x_labels)
        plt.legend()
        plt.grid(axis="y", alpha=0.3, linestyle="--")
        
        plt.savefig(os.path.join(report_dir, "signal_statistics_bar.png"), dpi=300, bbox_inches="tight")
        plt.close()
        print(f"Plot 1 saved: {os.path.join(report_dir, 'signal_statistics_bar.png')}")
        
        plt.figure(figsize=(12, 5))
        
        derived_breakout = self.evaluation_result["breakout_derived_metrics"]
        derived_breakdown = self.evaluation_result["breakdown_derived_metrics"]
        metrics_labels = ["Precision", "Recall", "F1-Score", "False Signal Rate"]
        breakout_metrics = [
            derived_breakout["precision"],
            derived_breakout["recall"],
            derived_breakout["f1_score"],
            derived_breakout["false_signal_rate"]
        ]
        breakdown_metrics = [
            derived_breakdown["precision"],
            derived_breakdown["recall"],
            derived_breakdown["f1_score"],
            derived_breakdown["false_signal_rate"]
        ]
        
        x = np.arange(len(metrics_labels))
        plt.bar(x - width/2, breakout_metrics, width, label="Breakout", color="#4169E1", alpha=0.8)
        plt.bar(x + width/2, breakdown_metrics, width, label="Breakdown", color="#FF6347", alpha=0.8)
        
        plt.title("Performance Metrics Comparison (Breakout vs Breakdown)", fontsize=12)
        plt.xlabel("Metrics", fontsize=10)
        plt.ylabel("Value (0-1)", fontsize=10)
        plt.xticks(x, metrics_labels)
        plt.ylim(0, 1.05)
        plt.legend()
        plt.grid(axis="y", alpha=0.3, linestyle="--")
        
        plt.savefig(os.path.join(report_dir, "performance_metrics_comparison.png"), dpi=300, bbox_inches="tight")
        plt.close()
        print(f"Plot 2 saved: {os.path.join(report_dir, 'performance_metrics_comparison.png')}")
        
        if not self.prices.empty:
            plt.figure(figsize=(16, 8))
            
            plt.plot(self.prices.values, label="Close Price", color="#000000", linewidth=1.2, alpha=0.7)
            
            breakout_indices = self.evaluation_result["verification_details"]["breakout_verification"]
            breakdown_indices = self.evaluation_result["verification_details"]["breakdown_verification"]
            
            for idx, res in zip(breakout_indices, self.breakout_verification):
                if res == "TPB":
                    plt.scatter(idx, self.prices.iloc[idx], color="darkgreen", s=80, alpha=0.9, marker="^", label="TPB (Valid Breakout)" if "TPB" not in plt.gca().get_legend_handles_labels()[1] else "")
                elif res == "FPB":
                    plt.scatter(idx, self.prices.iloc[idx], color="darkred", s=80, alpha=0.9, marker="^", label="FPB (Invalid Breakout)" if "FPB" not in plt.gca().get_legend_handles_labels()[1] else "")
            
            for idx, res in zip(breakdown_indices, self.breakdown_verification):
                if res == "TPBd":
                    plt.scatter(idx, self.prices.iloc[idx], color="darkblue", s=80, alpha=0.9, marker="v", label="TPBd (Valid Breakdown)" if "TPBd" not in plt.gca().get_legend_handles_labels()[1] else "")
                elif res == "FPBd":
                    plt.scatter(idx, self.prices.iloc[idx], color="darkorange", s=80, alpha=0.9, marker="v", label="FPBd (Invalid Breakdown)" if "FPBd" not in plt.gca().get_legend_handles_labels()[1] else "")
            
            swing_high_prices = self.prices.iloc[self.swing_highs].values if self.swing_highs else []
            swing_low_prices = self.prices.iloc[self.swing_lows].values if self.swing_lows else []
            if self.swing_highs:
                plt.scatter(self.swing_highs, swing_high_prices, color="red", s=40, alpha=0.6, marker="o", label="Swing Highs" if "Swing Highs" not in plt.gca().get_legend_handles_labels()[1] else "")
            if self.swing_lows:
                plt.scatter(self.swing_lows, swing_low_prices, color="green", s=40, alpha=0.6, marker="o", label="Swing Lows" if "Swing Lows" not in plt.gca().get_legend_handles_labels()[1] else "")
            
            plt.title("Price Trend with Verified Breakout/Breakdown & Swing Points", fontsize=12)
            plt.xlabel("Trading Day Index", fontsize=10)
            plt.ylabel("Close Price (USD)", fontsize=10)
            plt.legend(loc="best", fontsize=8)
            plt.grid(alpha=0.3, linestyle="--")
            
            plt.savefig(os.path.join(report_dir, "price_with_signals.png"), dpi=300, bbox_inches="tight")
            plt.close()
            print(f"Plot 3 saved: {os.path.join(report_dir, 'price_with_signals.png')}")
        
        print("All plots generated and saved successfully.")